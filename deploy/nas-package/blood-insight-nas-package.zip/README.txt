﻿Blood Insight NAS package

1. Upload this folder or zip to /volume1/docker/blood-insight
2. Preserve existing server/data if you want to keep users and reports
3. In Ugreen NAS Docker UI, redeploy/rebuild the project
4. App API base URL is http://pinkrainbow.duckdns.org:18082
