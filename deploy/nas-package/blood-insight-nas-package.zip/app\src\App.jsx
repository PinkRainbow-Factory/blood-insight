﻿import { useEffect, useMemo, useState } from "react";
import { defaultProfile, diseaseCatalog, metricDefinitions, sampleValues } from "./data";
import { fetchSession, loginUser, logoutUser, saveAiSettings, signupUser } from "./services/apiClient";
import { loadMedicalReportHistory, persistMedicalReport, requestMedicalAnalysis } from "./services/medicalAnalysisService";
import { extractLabMetricsFromImage, getSampleOcrPayload } from "./services/ocrService";

const STORAGE_KEYS = {
  token: "bloodInsight.authToken",
  profile: "bloodInsight.profile",
  labs: "bloodInsight.labs",
  customLabs: "bloodInsight.customLabs"
};

const NAV_ITEMS = [
  { id: "dashboard", label: "메인" },
  { id: "profile", label: "프로필" },
  { id: "labs", label: "수치 입력" },
  { id: "report", label: "리포트" },
  { id: "history", label: "기록" },
  { id: "settings", label: "AI 설정" }
];

function safeParse(rawValue, fallback) {
  try {
    return rawValue ? JSON.parse(rawValue) : fallback;
  } catch {
    return fallback;
  }
}

function loadStoredProfile() {
  return { ...defaultProfile, ...safeParse(localStorage.getItem(STORAGE_KEYS.profile), defaultProfile) };
}

function loadStoredLabs() {
  return { ...sampleValues, ...safeParse(localStorage.getItem(STORAGE_KEYS.labs), sampleValues) };
}

function loadStoredCustomLabs() {
  return safeParse(localStorage.getItem(STORAGE_KEYS.customLabs), []);
}

function normalizeText(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, "");
}

function classifyMetric(metric, rawValue) {
  const value = Number(rawValue);
  if (!Number.isFinite(value)) {
    return "unknown";
  }
  if (!Number.isFinite(metric?.range?.low) || !Number.isFinite(metric?.range?.high)) {
    return "unknown";
  }
  if (value < metric.range.low) {
    return "low";
  }
  if (value > metric.range.high) {
    return "high";
  }
  return "normal";
}

function buildMarkerPosition(metric, rawValue) {
  const value = Number(rawValue);
  if (!Number.isFinite(value)) {
    return 10;
  }
  const spread = metric.range.high - metric.range.low || 1;
  const min = metric.range.low - spread * 0.6;
  const max = metric.range.high + spread * 0.6;
  const clamped = Math.min(max, Math.max(min, value));
  return ((clamped - min) / (max - min)) * 100;
}

function formatMetricValue(rawValue) {
  const value = Number(rawValue);
  if (!Number.isFinite(value)) {
    return "-";
  }
  return Number.isInteger(value) ? value.toString() : value.toFixed(1);
}

function countAbnormal(labs) {
  return metricDefinitions.filter((metric) => {
    const status = classifyMetric(metric, labs[metric.code]);
    return status !== "normal" && status !== "unknown";
  }).length;
}

function reportList(value) {
  return Array.isArray(value) ? value.filter(Boolean) : [];
}

function StatusPill({ status }) {
  const labels = {
    normal: "정상 범위",
    high: "높음",
    low: "낮음",
    borderline: "확인 필요",
    unknown: "참고범위 없음"
  };

  return <span className={`status-pill status-${status}`}>{labels[status] || "확인 필요"}</span>;
}

function App() {
  const [session, setSession] = useState(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [activeView, setActiveView] = useState("dashboard");
  const [authMode, setAuthMode] = useState("signup");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [profile, setProfile] = useState(loadStoredProfile);
  const [labs, setLabs] = useState(loadStoredLabs);
  const [customLabs, setCustomLabs] = useState(loadStoredCustomLabs);
  const [customLabDraft, setCustomLabDraft] = useState({ name: "", code: "", value: "", unit: "", low: "", high: "" });
  const [analysis, setAnalysis] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState("");
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState("");
  const [selectedMetricCode, setSelectedMetricCode] = useState("");
  const [uploadedImage, setUploadedImage] = useState("");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [ocrBusy, setOcrBusy] = useState(false);
  const [ocrResult, setOcrResult] = useState(null);
  const [settingsDraft, setSettingsDraft] = useState({ provider: "gemini", openaiApiKey: "", geminiApiKey: "", openaiModel: "gpt-5", geminiModel: "gemini-3-flash" });
  const [settingsBusy, setSettingsBusy] = useState(false);
  const [settingsMessage, setSettingsMessage] = useState("");

  const selectedDisease = useMemo(
    () => diseaseCatalog.find((disease) => disease.code === profile.diseaseCode) || null,
    [profile.diseaseCode]
  );

  const combinedMetrics = useMemo(() => {
    const customMetricDefinitions = customLabs.map((item) => ({
      code: item.code,
      name: item.name,
      unit: item.unit || "",
      range: {
        low: item.low === "" ? Number.NaN : Number(item.low),
        high: item.high === "" ? Number.NaN : Number(item.high)
      },
      meaning: "사용자가 추가한 혈액검사 항목입니다.",
      highText: "입력한 참고범위와 비교해 높은 편인지 확인해 보세요.",
      lowText: "입력한 참고범위와 비교해 낮은 편인지 확인해 보세요.",
      generalTip: "검사표의 참고 범위를 함께 입력하면 해석 정확도가 더 좋아집니다."
    }));

    return [...metricDefinitions, ...customMetricDefinitions];
  }, [customLabs]);

  const selectedMetric = useMemo(
    () => combinedMetrics.find((metric) => metric.code === selectedMetricCode) || null,
    [combinedMetrics, selectedMetricCode]
  );

  const diseaseResults = useMemo(() => {
    if (profile.mode !== "patient") {
      return [];
    }

    const query = normalizeText(profile.diseaseQuery);
    return diseaseCatalog
      .filter((item) => {
        if (!query) {
          return true;
        }
        const searchStack = [item.code, item.name, item.group, ...(item.keywords || [])].map(normalizeText).join(" ");
        return searchStack.includes(query);
      })
      .slice(0, 12);
  }, [profile.mode, profile.diseaseQuery]);

  const abnormalCount = useMemo(() => countAbnormal(labs), [labs]);
  const readiness = {
    profile: Boolean(profile.displayName && profile.age),
    disease: profile.mode === "general" || Boolean(selectedDisease),
    apiKey:
      settingsDraft.provider === "gemini"
        ? Boolean(session?.user?.settings?.hasGeminiKey)
        : Boolean(session?.user?.settings?.hasOpenaiKey)
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.profile, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.labs, JSON.stringify(labs));
  }, [labs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.customLabs, JSON.stringify(customLabs));
  }, [customLabs]);

  useEffect(() => {
    const token = localStorage.getItem(STORAGE_KEYS.token);
    if (!token) {
      setSessionReady(true);
      return;
    }

    fetchSession(token)
      .then(({ user }) => {
        setSession({ token, user });
        setSettingsDraft((current) => ({
          ...current,
          provider: user.settings?.provider || "gemini",
          openaiModel: user.settings?.openaiModel || "gpt-5",
          geminiModel: user.settings?.geminiModel || "gemini-3-flash"
        }));
      })
      .catch(() => {
        localStorage.removeItem(STORAGE_KEYS.token);
        setSession(null);
      })
      .finally(() => setSessionReady(true));
  }, []);

  useEffect(() => {
    if (!session?.token) {
      setHistory([]);
      return;
    }

    setHistoryLoading(true);
    setHistoryError("");
    loadMedicalReportHistory({ token: session.token })
      .then(({ reports }) => setHistory(reports || []))
      .catch((error) => setHistoryError(error.message || "기록을 불러오지 못했습니다."))
      .finally(() => setHistoryLoading(false));
  }, [session?.token]);

  function updateProfile(field, value) {
    setProfile((current) => ({ ...current, [field]: value }));
  }

  function updateLab(code, value) {
    setLabs((current) => ({
      ...current,
      [code]: value === "" ? "" : Number(value)
    }));
  }

  function updateCustomLab(index, field, value) {
    setCustomLabs((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, [field]: value } : item));
  }

  function removeCustomLab(index) {
    setCustomLabs((current) => current.filter((_, itemIndex) => itemIndex !== index));
  }

  function handleAddCustomLab() {
    if (!customLabDraft.name.trim()) {
      return;
    }

    const code = (customLabDraft.code || customLabDraft.name)
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 20) || `CUSTOM_${Date.now()}`;

    setCustomLabs((current) => [
      ...current,
      {
        code,
        name: customLabDraft.name.trim(),
        value: customLabDraft.value === "" ? "" : Number(customLabDraft.value),
        unit: customLabDraft.unit.trim(),
        low: customLabDraft.low,
        high: customLabDraft.high
      }
    ]);

    setCustomLabDraft({ name: "", code: "", value: "", unit: "", low: "", high: "" });
  }

  async function handleAuthSubmit(event) {
    event.preventDefault();
    setAuthBusy(true);
    setAuthError("");

    try {
      const payload = authMode === "signup"
        ? await signupUser(authForm)
        : await loginUser({ email: authForm.email, password: authForm.password });

      localStorage.setItem(STORAGE_KEYS.token, payload.token);
      setSession(payload);
      setSettingsDraft({
        provider: payload.user.settings?.provider || "gemini",
        openaiApiKey: "",
        geminiApiKey: "",
        openaiModel: payload.user.settings?.openaiModel || "gpt-5",
        geminiModel: payload.user.settings?.geminiModel || "gemini-3-flash"
      });
      setAuthForm({ name: "", email: authForm.email, password: "" });
      setActiveView("dashboard");
    } catch (error) {
      setAuthError(error.message || "로그인에 실패했습니다.");
    } finally {
      setAuthBusy(false);
    }
  }

  async function handleLogout() {
    try {
      if (session?.token) {
        await logoutUser(session.token);
      }
    } catch {
      // ignore logout network errors and clear local session anyway
    }
    localStorage.removeItem(STORAGE_KEYS.token);
    setSession(null);
    setAnalysis(null);
    setActiveView("dashboard");
  }
  async function handleSaveSettings(event) {
    event.preventDefault();
    if (!session?.token) {
      return;
    }

    setSettingsBusy(true);
    setSettingsMessage("");

    try {
      const { user } = await saveAiSettings({
        token: session.token,
        provider: settingsDraft.provider,
        openaiApiKey: settingsDraft.openaiApiKey,
        geminiApiKey: settingsDraft.geminiApiKey,
        openaiModel: settingsDraft.openaiModel,
        geminiModel: settingsDraft.geminiModel
      });

      setSession((current) => ({ ...current, user }));
      setSettingsDraft((current) => ({
        ...current,
        provider: user.settings?.provider || "gemini",
        openaiApiKey: "",
        geminiApiKey: "",
        openaiModel: user.settings?.openaiModel || current.openaiModel || "gpt-5",
        geminiModel: user.settings?.geminiModel || current.geminiModel || "gemini-3-flash"
      }));
      setSettingsMessage("AI 설정이 저장되었습니다. 이제 저장한 키로만 분석이 동작합니다.");
    } catch (error) {
      setSettingsMessage(error.message || "설정 저장에 실패했습니다.");
    } finally {
      setSettingsBusy(false);
    }
  }

  async function handleGenerateReport() {
    if (!session?.token) {
      setAuthError("먼저 로그인해 주세요.");
      return;
    }

    const providerKeyReady = settingsDraft.provider === "gemini"
      ? session.user?.settings?.hasGeminiKey
      : session.user?.settings?.hasOpenaiKey;

    if (!providerKeyReady) {
      setActiveView("settings");
      setAnalysisError("먼저 AI 설정에서 사용할 API 키를 저장해 주세요.");
      return;
    }

    setAnalysisLoading(true);
    setAnalysisError("");

    try {
      const baseLabs = Object.fromEntries(
        Object.entries(labs).filter(([, value]) => value !== "" && Number.isFinite(Number(value)))
      );
      const extraLabs = Object.fromEntries(
        customLabs
          .filter((item) => item.name && item.value !== "" && Number.isFinite(Number(item.value)))
          .map((item) => [
            item.code,
            {
              value: Number(item.value),
              label: item.name,
              unit: item.unit,
              low: item.low === "" ? null : Number(item.low),
              high: item.high === "" ? null : Number(item.high)
            }
          ])
      );
      const cleanLabs = { ...baseLabs, ...extraLabs };

      const result = await requestMedicalAnalysis({
        provider: settingsDraft.provider,
        profile,
        disease: selectedDisease,
        labs: cleanLabs,
        token: session.token
      });

      setAnalysis(result);
      await persistMedicalReport({
        profile,
        disease: selectedDisease,
        labs: cleanLabs,
        analysis: result,
        provider: settingsDraft.provider,
        token: session.token
      });

      const { reports } = await loadMedicalReportHistory({ token: session.token });
      setHistory(reports || []);
      setActiveView("report");
    } catch (error) {
      setAnalysisError(error.message || "리포트 생성에 실패했습니다.");
      setActiveView("report");
    } finally {
      setAnalysisLoading(false);
    }
  }

  async function handleRunOcr() {
    setOcrBusy(true);
    setAnalysisError("");
    try {
      const payload = uploadedFile ? await extractLabMetricsFromImage(uploadedFile) : getSampleOcrPayload();
      setOcrResult(payload);
    } catch (error) {
      setAnalysisError(error.message || "OCR 분석에 실패했습니다.");
    } finally {
      setOcrBusy(false);
    }
  }

  function handleApplyOcr() {
    if (!ocrResult?.matches?.length) {
      return;
    }
    setLabs((current) => {
      const next = { ...current };
      ocrResult.matches.forEach((match) => {
        if (metricDefinitions.some((metric) => metric.code === match.code)) {
          next[match.code] = match.value;
        }
      });
      return next;
    });
    setCustomLabs((current) => {
      const next = [...current];
      ocrResult.matches.forEach((match) => {
        if (!metricDefinitions.some((metric) => metric.code === match.code)) {
          const existingIndex = next.findIndex((item) => item.code === match.code);
          const customItem = {
            code: match.code,
            name: match.label,
            value: match.value,
            unit: match.unit || "",
            low: "",
            high: ""
          };
          if (existingIndex >= 0) {
            next[existingIndex] = { ...next[existingIndex], ...customItem };
          } else {
            next.push(customItem);
          }
        }
      });
      return next;
    });
    setActiveView("labs");
  }

  function handleImageChange(event) {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }
    setUploadedFile(file);
    setUploadedImage(URL.createObjectURL(file));
    setOcrResult(null);
  }

  function handleLoadReport(report) {
    if (report?.labs) {
      setLabs((current) => ({ ...current, ...report.labs }));
    }
    if (report?.profile) {
      setProfile((current) => ({ ...current, ...report.profile }));
    }
    setAnalysis(report.analysis || null);
    setActiveView("report");
  }

  const summaryText = analysis?.aiResult?.overall_summary || analysis?.structured?.summary?.headline || "아직 생성된 AI 리포트가 없습니다.";
  const priorityItems = reportList(analysis?.aiResult?.priority_items);
  const managementTips = reportList(analysis?.aiResult?.management_tips || analysis?.aiResult?.care_tips);
  const clinicianQuestions = reportList(analysis?.aiResult?.questions_for_clinician || analysis?.aiResult?.questions);

  if (!sessionReady) {
    return <div className="loading-screen">세션을 확인하는 중입니다...</div>;
  }

  if (!session) {
    return (
      <div className="auth-shell">
        <div className="auth-hero">
          <div className="brand-badge">Blood Insight AI</div>
          <h1>혈액검사 결과를 예쁘고 명확하게 읽어주는 개인용 AI 앱</h1>
          <p>
            회원가입 후 AI 키를 직접 저장하면, 그 키로만 분석이 돌아가도록 바꿔두었습니다. 이제 개인 테스트 용도로도 훨씬 안전하게 사용할 수 있습니다.
          </p>
          <div className="hero-checks">
            <span>회원 전용 기록 저장</span>
            <span>Gemini / ChatGPT 키 직접 입력</span>
            <span>환자용 질환 코드 검색 강화</span>
          </div>
        </div>

        <form className="auth-card" onSubmit={handleAuthSubmit}>
          <div className="auth-switch">
            <button type="button" className={authMode === "signup" ? "active" : ""} onClick={() => setAuthMode("signup")}>회원가입</button>
            <button type="button" className={authMode === "login" ? "active" : ""} onClick={() => setAuthMode("login")}>로그인</button>
          </div>

          {authMode === "signup" && (
            <label>
              이름
              <input value={authForm.name} onChange={(event) => setAuthForm((current) => ({ ...current, name: event.target.value }))} placeholder="예: Pink Rainbow" />
            </label>
          )}

          <label>
            이메일
            <input type="email" value={authForm.email} onChange={(event) => setAuthForm((current) => ({ ...current, email: event.target.value }))} placeholder="name@example.com" />
          </label>

          <label>
            비밀번호
            <input type="password" value={authForm.password} onChange={(event) => setAuthForm((current) => ({ ...current, password: event.target.value }))} placeholder="6자 이상" />
          </label>

          {authError && <div className="inline-error">{authError}</div>}

          <button className="primary-btn wide" type="submit" disabled={authBusy}>
            {authBusy ? "처리 중..." : authMode === "signup" ? "계정 만들기" : "로그인"}
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <div className="ambient ambient-a" />
      <div className="ambient ambient-b" />
      <div className="ambient ambient-c" />

      <aside className="sidebar glass-card">
        <div className="sidebar-brand">
          <div className="brand-mark">BI</div>
          <div>
            <strong>Blood Insight</strong>
            <p>{session.user?.name}님 전용 리포트 앱</p>
          </div>
        </div>

        <nav className="menu-list">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`menu-item ${activeView === item.id ? "active" : ""}`}
              onClick={() => setActiveView(item.id)}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-status">
          <div>
            <span className="sidebar-label">AI 공급자</span>
            <strong>{settingsDraft.provider === "gemini" ? "Gemini" : "ChatGPT"}</strong>
          </div>
          <div>
            <span className="sidebar-label">질환 선택</span>
            <strong>{selectedDisease ? selectedDisease.name : profile.mode === "patient" ? "선택 필요" : "일반 해설 모드"}</strong>
          </div>
          <div>
            <span className="sidebar-label">이상 수치</span>
            <strong>{abnormalCount}개</strong>
          </div>
        </div>

        <button className="ghost-btn wide" type="button" onClick={handleLogout}>로그아웃</button>
      </aside>

      <div className="content-area">
        <header className="topbar glass-card">
          <div>
            <p className="eyebrow">PERSONAL BLOOD AI</p>
            <h2>{activeView === "dashboard" ? "메인 대시보드" : NAV_ITEMS.find((item) => item.id === activeView)?.label}</h2>
          </div>
          <div className="topbar-actions">
            <button type="button" className="ghost-btn" onClick={() => setActiveView("settings")}>AI 설정</button>
            <button type="button" className="primary-btn" onClick={handleGenerateReport} disabled={analysisLoading}>
              {analysisLoading ? "AI 분석 중..." : "AI 리포트 생성"}
            </button>
          </div>
        </header>

        {activeView === "dashboard" && (
          <section className="screen-grid dashboard-grid">
            <article className="glass-card hero-card">
              <div className="chip-row">
                <span className="chip">회원 로그인 완료</span>
                <span className={`chip ${readiness.apiKey ? "good" : "warn"}`}>{readiness.apiKey ? "API 키 준비됨" : "API 키 필요"}</span>
              </div>
              <h3>{session.user?.name}님, 오늘도 혈액 수치를 한눈에 정리해볼까요?</h3>
              <p>
                메인 메뉴에서 프로필, 수치 입력, 리포트, AI 설정을 바로 이동할 수 있게 구조를 다시 잡아두었습니다. 이제 각 화면이 실제로 분리되어 동작합니다.
              </p>
              <div className="cta-row">
                <button className="primary-btn" type="button" onClick={() => setActiveView("labs")}>검사 수치 입력하기</button>
                <button className="ghost-btn" type="button" onClick={() => setActiveView("profile")}>프로필 정리하기</button>
              </div>
            </article>

            <article className="glass-card summary-card">
              <h3>준비 상태</h3>
              <div className="status-stack">
                <div className={`status-line ${readiness.profile ? "done" : "todo"}`}>프로필 입력 {readiness.profile ? "완료" : "필요"}</div>
                <div className={`status-line ${readiness.disease ? "done" : "todo"}`}>질환 맥락 선택 {readiness.disease ? "완료" : "필요"}</div>
                <div className={`status-line ${readiness.apiKey ? "done" : "todo"}`}>AI API 키 저장 {readiness.apiKey ? "완료" : "필요"}</div>
              </div>
              <div className="orb-wrap">
                <div className="orb-ring"><span>{abnormalCount}</span><small>주의 수치</small></div>
              </div>
            </article>

            <article className="glass-card mini-card">
              <h3>선택된 질환</h3>
              <p>{selectedDisease ? `${selectedDisease.name} (${selectedDisease.code})` : profile.mode === "patient" ? "아직 환자용 질환을 선택하지 않았습니다." : "일반 사용자용 혈액 해설 모드입니다."}</p>
              {selectedDisease && <small>{selectedDisease.note}</small>}
            </article>

            <article className="glass-card mini-card">
              <h3>최근 리포트</h3>
              <p>{history[0]?.analysis?.aiResult?.overall_summary || "아직 저장된 리포트가 없습니다."}</p>
              {history[0] && <button type="button" className="ghost-btn" onClick={() => handleLoadReport(history[0])}>가장 최근 리포트 열기</button>}
            </article>
          </section>
        )}

        {activeView === "profile" && (
          <section className="screen-grid two-column">
            <article className="glass-card">
              <div className="section-head">
                <h3>개인 프로필</h3>
                <span className="chip">개인화 해설</span>
              </div>
              <div className="form-grid">
                <label>
                  표시 이름
                  <input value={profile.displayName} onChange={(event) => updateProfile("displayName", event.target.value)} placeholder="예: 민지" />
                </label>
                <label>
                  나이
                  <input value={profile.age} onChange={(event) => updateProfile("age", event.target.value)} placeholder="예: 36" />
                </label>
                <label>
                  성별
                  <select value={profile.sex} onChange={(event) => updateProfile("sex", event.target.value)}>
                    <option value="female">여성</option>
                    <option value="male">남성</option>
                    <option value="other">기타</option>
                  </select>
                </label>
                <label>
                  사용자 유형
                  <select value={profile.mode} onChange={(event) => updateProfile("mode", event.target.value)}>
                    <option value="general">일반인</option>
                    <option value="patient">환자</option>
                  </select>
                </label>
              </div>
              <label>
                복용약 / 치료 맥락
                <textarea rows="3" value={profile.medications} onChange={(event) => updateProfile("medications", event.target.value)} placeholder="항암치료, 스테로이드, 항생제 등" />
              </label>
              <label>
                메모
                <textarea rows="4" value={profile.notes} onChange={(event) => updateProfile("notes", event.target.value)} placeholder="최근 감염, 수혈, 입원, 컨디션 변화 등을 적어두면 리포트 문맥이 좋아집니다." />
              </label>
            </article>

            <article className="glass-card">
              <div className="section-head">
                <h3>질환 코드 검색</h3>
                <span className="chip accent">검색 강화</span>
              </div>
              {profile.mode === "patient" ? (
                <>
                  <label>
                    질환명 또는 코드 검색
                    <input value={profile.diseaseQuery} onChange={(event) => updateProfile("diseaseQuery", event.target.value)} placeholder="예: 백혈병, AML, 당뇨, CKD, 림프종" />
                  </label>
                  <div className="search-results">
                    {diseaseResults.map((item) => (
                      <button key={item.code} type="button" className={`search-result ${profile.diseaseCode === item.code ? "active" : ""}`} onClick={() => updateProfile("diseaseCode", item.code)}>
                        <strong>{item.name}</strong>
                        <span>{item.code} · {item.group}</span>
                        <small>{item.note}</small>
                      </button>
                    ))}
                  </div>
                  {selectedDisease && (
                    <div className="selection-card">
                      <p className="eyebrow">선택된 질환</p>
                      <h4>{selectedDisease.name}</h4>
                      <p>{selectedDisease.code} · {selectedDisease.group}</p>
                      <small>우선 보는 수치: {selectedDisease.focus.join(", ")}</small>
                    </div>
                  )}
                </>
              ) : (
                <div className="empty-card">일반인 모드에서는 질환 선택 없이 정상범위 비교와 생활관리 중심으로 설명합니다.</div>
              )}
            </article>
          </section>
        )}

        {activeView === "labs" && (
          <section className="screen-grid two-column">
            <article className="glass-card">
              <div className="section-head">
                <h3>혈액 수치 입력</h3>
                <div className="chip-row">
                  <button type="button" className="ghost-btn small" onClick={() => setLabs(sampleValues)}>샘플 값 채우기</button>
                  <button type="button" className="ghost-btn small" onClick={() => setActiveView("report")}>리포트 보기</button>
                </div>
              </div>
              <div className="metric-grid">
                {combinedMetrics.map((metric) => {
                  const customIndex = customLabs.findIndex((item) => item.code === metric.code);
                  const metricValue = customIndex >= 0 ? customLabs[customIndex]?.value : labs[metric.code];
                  const status = classifyMetric(metric, metricValue);
                  return (
                    <button key={metric.code} type="button" className="metric-card" onClick={() => setSelectedMetricCode(metric.code)}>
                      <div className="metric-head">
                        <div>
                          <strong>{metric.name}</strong>
                          <span>{metric.code}</span>
                        </div>
                        <StatusPill status={status} />
                      </div>
                      <label className="metric-input-wrap" onClick={(event) => event.stopPropagation()}>
                        <input
                          type="number"
                          step="0.1"
                          value={metricValue}
                          onChange={(event) => customIndex >= 0 ? updateCustomLab(customIndex, "value", event.target.value === "" ? "" : Number(event.target.value)) : updateLab(metric.code, event.target.value)}
                        />
                      </label>
                      <div className="metric-footer">
                        <span>{formatMetricValue(metricValue)} {metric.unit}</span>
                        <small>{Number.isFinite(metric.range.low) && Number.isFinite(metric.range.high) ? `정상 ${metric.range.low} - ${metric.range.high}` : "참고 범위 직접 입력 가능"}</small>
                      </div>
                      {Number.isFinite(metric.range.low) && Number.isFinite(metric.range.high) && (
                        <div className="range-bar">
                          <div className="range-marker" style={{ left: `${buildMarkerPosition(metric, metricValue)}%` }} />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="custom-lab-panel">
                <div className="section-head">
                  <h3>커스텀 항목 추가</h3>
                  <span className="chip accent">수동 추가</span>
                </div>
                <div className="form-grid">
                  <label>
                    항목명
                    <input value={customLabDraft.name} onChange={(event) => setCustomLabDraft((current) => ({ ...current, name: event.target.value }))} placeholder="예: LDL, TSH, Magnesium" />
                  </label>
                  <label>
                    코드
                    <input value={customLabDraft.code} onChange={(event) => setCustomLabDraft((current) => ({ ...current, code: event.target.value }))} placeholder="예: LDL" />
                  </label>
                  <label>
                    값
                    <input type="number" step="0.1" value={customLabDraft.value} onChange={(event) => setCustomLabDraft((current) => ({ ...current, value: event.target.value }))} />
                  </label>
                  <label>
                    단위
                    <input value={customLabDraft.unit} onChange={(event) => setCustomLabDraft((current) => ({ ...current, unit: event.target.value }))} placeholder="mg/dL" />
                  </label>
                  <label>
                    참고범위 하한
                    <input type="number" step="0.1" value={customLabDraft.low} onChange={(event) => setCustomLabDraft((current) => ({ ...current, low: event.target.value }))} />
                  </label>
                  <label>
                    참고범위 상한
                    <input type="number" step="0.1" value={customLabDraft.high} onChange={(event) => setCustomLabDraft((current) => ({ ...current, high: event.target.value }))} />
                  </label>
                </div>
                <div className="cta-row">
                  <button type="button" className="ghost-btn" onClick={handleAddCustomLab}>커스텀 항목 추가</button>
                </div>
                <div className="history-grid">
                  {customLabs.map((item, index) => (
                    <div className="history-card" key={`${item.code}-${index}`}>
                      <div className="history-topline">
                        <strong>{item.name}</strong>
                        <button type="button" className="ghost-btn small" onClick={() => removeCustomLab(index)}>삭제</button>
                      </div>
                      <div className="form-grid">
                        <label>
                          값
                          <input type="number" step="0.1" value={item.value} onChange={(event) => updateCustomLab(index, "value", event.target.value === "" ? "" : Number(event.target.value))} />
                        </label>
                        <label>
                          단위
                          <input value={item.unit} onChange={(event) => updateCustomLab(index, "unit", event.target.value)} />
                        </label>
                        <label>
                          참고범위 하한
                          <input type="number" step="0.1" value={item.low} onChange={(event) => updateCustomLab(index, "low", event.target.value)} />
                        </label>
                        <label>
                          참고범위 상한
                          <input type="number" step="0.1" value={item.high} onChange={(event) => updateCustomLab(index, "high", event.target.value)} />
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </article>

            <article className="glass-card">
              <div className="section-head">
                <h3>사진 / 캡처 OCR</h3>
                <span className="chip">촬영 / 업로드</span>
              </div>
              <label className="upload-zone">
                <input type="file" accept="image/*" capture="environment" onChange={handleImageChange} />
                <div>
                  <strong>검사표 사진 찍기 또는 업로드</strong>
                  <p>카메라 촬영, 앨범 선택, 캡처본 업로드를 모두 지원합니다. OCR 후 직접 검토하고 반영할 수 있습니다.</p>
                </div>
              </label>
              {uploadedImage && <div className="image-preview"><img src={uploadedImage} alt="검사표 미리보기" /></div>}
              <div className="cta-row">
                <button type="button" className="primary-btn" onClick={handleRunOcr} disabled={ocrBusy}>{ocrBusy ? "OCR 분석 중..." : "OCR 분석"}</button>
                <button type="button" className="ghost-btn" onClick={() => setOcrResult(getSampleOcrPayload())}>샘플 OCR</button>
              </div>
              <div className="empty-card">OCR이 모르는 항목도 아래 커스텀 혈액검사로 자동 연결하거나 직접 추가해서 AI 설명에 포함할 수 있게 설계되어 있습니다.</div>

              {ocrResult && (
                <div className="ocr-panel">
                  <div className="ocr-list">
                    {ocrResult.matches.map((match) => (
                      <div className="ocr-card" key={match.code}>
                        <div>
                          <strong>{match.label}</strong>
                          <span>{match.code}</span>
                        </div>
                        <div>
                          <strong>{formatMetricValue(match.value)}</strong>
                          <small>신뢰도 {Math.round(match.confidence * 100)}%</small>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button type="button" className="primary-btn wide" onClick={handleApplyOcr}>검토값 반영하기</button>
                </div>
              )}
            </article>
          </section>
        )}

        {activeView === "report" && (
          <section className="screen-grid report-grid">
            <article className="glass-card report-hero">
              <div className="chip-row">
                <span className="chip accent">{settingsDraft.provider === "gemini" ? "Gemini" : "ChatGPT"}</span>
                <span className="chip">{selectedDisease ? selectedDisease.name : "일반 해설"}</span>
              </div>
              <h3>AI 종합 해설</h3>
              <p>{analysisLoading ? "수치를 기반으로 AI 리포트를 생성하고 있습니다..." : summaryText}</p>
              {analysisError && <div className="inline-error">{analysisError}</div>}
              <div className="cta-row">
                <button type="button" className="primary-btn" onClick={handleGenerateReport} disabled={analysisLoading}>다시 생성</button>
                <button type="button" className="ghost-btn" onClick={() => setActiveView("history")}>기록 보기</button>
              </div>
            </article>

            <article className="glass-card summary-card">
              <h3>핵심 요약</h3>
              <div className="status-stack compact">
                <div className="status-line done">이상 수치 {abnormalCount}개</div>
                <div className={`status-line ${selectedDisease ? "done" : "todo"}`}>{selectedDisease ? `${selectedDisease.name} 문맥 적용` : "일반 해설 문맥"}</div>
                <div className="status-line done">기본 AI {settingsDraft.provider === "gemini" ? "Gemini" : "ChatGPT"}</div>
              </div>
            </article>

            <article className="glass-card list-card">
              <h3>우선 확인 항목</h3>
              {priorityItems.length ? priorityItems.map((item, index) => <div key={`${item}-${index}`} className="bullet-card">{item}</div>) : <div className="empty-card">AI 우선 항목이 아직 없습니다. 분석 후 여기에 표시됩니다.</div>}
            </article>

            <article className="glass-card list-card">
              <h3>관리 포인트</h3>
              {managementTips.length ? managementTips.map((item, index) => <div key={`${item}-${index}`} className="bullet-card">{item}</div>) : <div className="empty-card">생활관리/상담 포인트가 여기에 정리됩니다.</div>}
            </article>

            <article className="glass-card list-card">
              <h3>의료진에게 물어볼 질문</h3>
              {clinicianQuestions.length ? clinicianQuestions.map((item, index) => <div key={`${item}-${index}`} className="bullet-card">{item}</div>) : <div className="empty-card">질문 추천은 AI 응답에 따라 채워집니다.</div>}
            </article>

            <article className="glass-card list-card">
              <h3>수치 카드</h3>
              <div className="metric-grid compact-grid">
                {combinedMetrics.map((metric) => {
                  const metricValue = customLabs.find((item) => item.code === metric.code)?.value ?? labs[metric.code];
                  const status = classifyMetric(metric, metricValue);
                  return (
                    <button key={metric.code} type="button" className="metric-card compact" onClick={() => setSelectedMetricCode(metric.code)}>
                      <div className="metric-head">
                        <div>
                          <strong>{metric.code}</strong>
                          <span>{metric.name}</span>
                        </div>
                        <StatusPill status={status} />
                      </div>
                      <div className="metric-footer">
                        <span>{formatMetricValue(metricValue)} {metric.unit}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </article>
          </section>
        )}

        {activeView === "history" && (
          <section className="screen-grid">
            <article className="glass-card">
              <div className="section-head">
                <h3>저장된 리포트 기록</h3>
                <span className="chip">회원별 저장</span>
              </div>
              {historyLoading && <div className="empty-card">기록을 불러오는 중입니다...</div>}
              {historyError && <div className="inline-error">{historyError}</div>}
              <div className="history-grid">
                {history.map((report) => (
                  <button key={report.id} type="button" className="history-card" onClick={() => handleLoadReport(report)}>
                    <div className="history-topline">
                      <strong>{report.disease?.name || (report.profile?.mode === "patient" ? "환자 모드 리포트" : "일반 해설 리포트")}</strong>
                      <span>{new Date(report.createdAt).toLocaleString("ko-KR")}</span>
                    </div>
                    <p>{report.analysis?.aiResult?.overall_summary || "저장된 리포트"}</p>
                    <small>{report.provider === "openai" ? "ChatGPT" : "Gemini"}</small>
                  </button>
                ))}
              </div>
              {!historyLoading && history.length === 0 && <div className="empty-card">아직 저장된 리포트가 없습니다.</div>}
            </article>
          </section>
        )}

        {activeView === "settings" && (
          <section className="screen-grid two-column">
            <article className="glass-card">
              <div className="section-head">
                <h3>AI 설정</h3>
                <span className="chip accent">사용자 키 전용</span>
              </div>
              <form className="settings-form" onSubmit={handleSaveSettings}>
                <div className="toggle-row">
                  <button type="button" className={settingsDraft.provider === "gemini" ? "toggle-btn active" : "toggle-btn"} onClick={() => setSettingsDraft((current) => ({ ...current, provider: "gemini" }))}>Gemini</button>
                  <button type="button" className={settingsDraft.provider === "openai" ? "toggle-btn active" : "toggle-btn"} onClick={() => setSettingsDraft((current) => ({ ...current, provider: "openai" }))}>ChatGPT</button>
                </div>

                <label>
                  Gemini 모델명
                  <input value={settingsDraft.geminiModel} onChange={(event) => setSettingsDraft((current) => ({ ...current, geminiModel: event.target.value }))} placeholder="예: gemini-3-flash 또는 gemini-3-flash-preview" />
                </label>
                <label>
                  Gemini API Key
                  <input value={settingsDraft.geminiApiKey} onChange={(event) => setSettingsDraft((current) => ({ ...current, geminiApiKey: event.target.value }))} placeholder="필요할 때만 입력 또는 교체" />
                </label>
                <label>
                  ChatGPT 모델명
                  <input value={settingsDraft.openaiModel} onChange={(event) => setSettingsDraft((current) => ({ ...current, openaiModel: event.target.value }))} placeholder="예: gpt-5" />
                </label>
                <label>
                  ChatGPT API Key
                  <input value={settingsDraft.openaiApiKey} onChange={(event) => setSettingsDraft((current) => ({ ...current, openaiApiKey: event.target.value }))} placeholder="필요할 때만 입력 또는 교체" />
                </label>

                <div className="key-status-grid">
                  <div className="status-box">
                    <span>Gemini 저장 여부</span>
                    <strong>{session.user?.settings?.hasGeminiKey ? "저장됨" : "없음"}</strong>
                  </div>
                  <div className="status-box">
                    <span>ChatGPT 저장 여부</span>
                    <strong>{session.user?.settings?.hasOpenaiKey ? "저장됨" : "없음"}</strong>
                  </div>
                </div>

                {settingsMessage && <div className="inline-note">{settingsMessage}</div>}

                <button type="submit" className="primary-btn wide" disabled={settingsBusy}>{settingsBusy ? "저장 중..." : "AI 설정 저장"}</button>
              </form>
            </article>

            <article className="glass-card info-card">
              <h3>지금 바뀐 점</h3>
              <div className="bullet-card">로그인한 사용자는 서버 공용 키가 아니라, 본인 계정에 저장한 API 키로만 분석이 진행됩니다.</div>
              <div className="bullet-card">Gemini와 ChatGPT 모델명도 여기서 직접 바꿀 수 있습니다.</div>
              <div className="bullet-card">키를 바꾸면 이후 리포트는 새 키 기준으로 생성됩니다.</div>
              <div className="bullet-card">정식 배포 전 개인 테스트 용도로 쓰기 좋은 구조입니다.</div>
            </article>
          </section>
        )}
      </div>

      <nav className="mobile-nav glass-card">
        {NAV_ITEMS.map((item) => (
          <button key={item.id} type="button" className={activeView === item.id ? "active" : ""} onClick={() => setActiveView(item.id)}>{item.label}</button>
        ))}
      </nav>

      {selectedMetric && (
        <div className="modal-shell" onClick={() => setSelectedMetricCode("")}>
          <div className="modal-card" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="close-btn" onClick={() => setSelectedMetricCode("")}>닫기</button>
            <p className="eyebrow">METRIC DETAIL</p>
            <h3>{selectedMetric.name} ({selectedMetric.code})</h3>
            {(() => {
              const currentValue = customLabs.find((item) => item.code === selectedMetric.code)?.value ?? labs[selectedMetric.code];
              const currentStatus = classifyMetric(selectedMetric, currentValue);
              return (
            <div className="modal-stack">
              <div className="modal-block">
                <strong>현재 값</strong>
                <p>{formatMetricValue(currentValue)} {selectedMetric.unit}</p>
              </div>
              <div className="modal-block">
                <strong>의미</strong>
                <p>{selectedMetric.meaning}</p>
              </div>
              <div className="modal-block">
                <strong>정상 범위</strong>
                <p>{Number.isFinite(selectedMetric.range.low) && Number.isFinite(selectedMetric.range.high) ? `${selectedMetric.range.low} - ${selectedMetric.range.high}` : "입력한 참고 범위가 없으면 AI가 일반 설명 중심으로 안내합니다."}</p>
              </div>
              <div className="modal-block">
                <strong>관리 팁</strong>
                <p>{currentStatus === "high" ? selectedMetric.highText : currentStatus === "low" ? selectedMetric.lowText : selectedMetric.generalTip}</p>
              </div>
            </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
