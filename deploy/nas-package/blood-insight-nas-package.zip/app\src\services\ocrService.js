﻿import Tesseract from "tesseract.js";

const metricMatchers = [
  { code: "WBC", label: "백혈구", aliases: ["WBC", "백혈구"] },
  { code: "RBC", label: "적혈구", aliases: ["RBC", "적혈구"] },
  { code: "HGB", label: "혈색소", aliases: ["HGB", "Hb", "Hemoglobin", "혈색소", "헤모글로빈"] },
  { code: "HCT", label: "헤마토크릿", aliases: ["HCT", "Hematocrit", "헤마토크릿"] },
  { code: "MCV", label: "MCV", aliases: ["MCV"] },
  { code: "MCH", label: "MCH", aliases: ["MCH"] },
  { code: "MCHC", label: "MCHC", aliases: ["MCHC"] },
  { code: "PLT", label: "혈소판", aliases: ["PLT", "Platelet", "혈소판"] },
  { code: "NEUT", label: "호중구", aliases: ["NEUT", "Neutrophil", "호중구"] },
  { code: "LYM", label: "림프구", aliases: ["LYM", "Lymphocyte", "림프구"] },
  { code: "CRP", label: "CRP", aliases: ["CRP", "C-reactive protein"] },
  { code: "AST", label: "AST", aliases: ["AST", "SGOT"] },
  { code: "ALT", label: "ALT", aliases: ["ALT", "SGPT"] },
  { code: "BUN", label: "BUN", aliases: ["BUN", "Blood Urea Nitrogen", "요소질소"] },
  { code: "CREAT", label: "크레아티닌", aliases: ["Creatinine", "CREAT", "Cr", "크레아티닌"] },
  { code: "GLU", label: "포도당", aliases: ["Glucose", "GLU", "포도당", "혈당"] },
  { code: "FERRITIN", label: "페리틴", aliases: ["Ferritin", "FERRITIN", "페리틴"] },
  { code: "LDH", label: "LDH", aliases: ["LDH"] },
  { code: "ESR", label: "ESR", aliases: ["ESR"] },
  { code: "HBA1C", label: "당화혈색소", aliases: ["HbA1c", "A1c", "HBA1C", "당화혈색소"] }
];

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function parseValueFromText(text, aliases) {
  for (const alias of aliases) {
    const pattern = new RegExp(`${escapeRegExp(alias)}[^\\d]{0,12}(\\d+(?:[.,]\\d+)?)`, "i");
    const match = text.match(pattern);
    if (match) {
      return Number(match[1].replace(/,/g, "."));
    }
  }
  return null;
}

function buildGenericMatches(rawText, knownCodes) {
  const lines = rawText.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const genericMatches = [];

  lines.forEach((line) => {
    const match = line.match(/^([A-Za-z가-힣][A-Za-z0-9가-힣/()_. -]{1,24})\s+(\d+(?:[.,]\d+)?)(?:\s*([%A-Za-z/._-]+))?$/);
    if (!match) {
      return;
    }

    const label = match[1].trim();
    const code = label.toUpperCase().replace(/[^A-Z0-9]/g, "_").replace(/^_+|_+$/g, "").slice(0, 20);
    if (!code || knownCodes.has(code)) {
      return;
    }

    genericMatches.push({
      code,
      label,
      value: Number(match[2].replace(/,/g, ".")),
      unit: match[3] || "",
      confidence: 0.72,
      source: "ocr",
      isCustom: true
    });
  });

  return genericMatches;
}

export function extractLabMetricsFromText(rawText) {
  const knownMatches = metricMatchers
    .map((matcher) => {
      const value = parseValueFromText(rawText, matcher.aliases);
      if (value === null || Number.isNaN(value)) return null;
      return {
        code: matcher.code,
        label: matcher.label,
        value,
        confidence: 0.88,
        source: "ocr"
      };
    })
    .filter(Boolean);

  const knownCodes = new Set(knownMatches.map((item) => item.code));
  const genericMatches = buildGenericMatches(rawText, knownCodes);

  return { rawText, matches: [...knownMatches, ...genericMatches] };
}

export async function extractLabMetricsFromImage(file) {
  const result = await Tesseract.recognize(file, "eng+kor");
  const rawText = result?.data?.text || "";
  const parsed = extractLabMetricsFromText(rawText);
  return {
    rawText,
    matches: parsed.matches.map((item) => ({
      ...item,
      confidence: result?.data?.confidence ? Math.min(0.99, Math.max(item.confidence || 0.72, result.data.confidence / 100)) : item.confidence
    }))
  };
}

export function getSampleOcrPayload() {
  return extractLabMetricsFromText(`
    CBC\n    WBC 13.8\n    RBC 3.42\n    Hb 9.8\n    HCT 31.2\n    PLT 118\n    CRP 16.2\n    AST 42\n    ALT 58\n    BUN 24\n    Creatinine 1.1\n    Glucose 114\n    Ferritin 18\n    Magnesium 2.0 mg/dL\n    TSH 5.6 uIU/mL\n  `);
}
