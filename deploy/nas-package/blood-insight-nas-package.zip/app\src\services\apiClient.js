﻿import { Capacitor, CapacitorHttp } from "@capacitor/core";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

function parseNativeData(data) {
  if (typeof data === "string") {
    try {
      return JSON.parse(data);
    } catch {
      return {};
    }
  }
  return data || {};
}

async function request(path, { method = "GET", body, token } = {}) {
  const url = `${API_BASE}${path}`;
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };

  if (Capacitor.isNativePlatform()) {
    const response = await CapacitorHttp.request({
      url,
      method,
      headers,
      data: body
    });

    const data = parseNativeData(response.data);
    if (response.status < 200 || response.status >= 300) {
      throw new Error(data.message || data.error || "Request failed");
    }
    return data;
  }

  const response = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || data.error || "Request failed");
  }
  return data;
}

export async function signupUser(payload) {
  return request("/api/auth/signup", { method: "POST", body: payload });
}

export async function loginUser(payload) {
  return request("/api/auth/login", { method: "POST", body: payload });
}

export async function fetchSession(token) {
  return request("/api/auth/me", { token });
}

export async function logoutUser(token) {
  return request("/api/auth/logout", { method: "POST", token });
}

export async function saveAiSettings({ token, provider, openaiApiKey, geminiApiKey, openaiModel, geminiModel }) {
  return request("/api/auth/settings/ai", {
    method: "PUT",
    token,
    body: {
      provider,
      openaiApiKey,
      geminiApiKey,
      openaiModel,
      geminiModel
    }
  });
}

export async function analyzeViaProxy({ provider, profile, disease, labs, token }) {
  return request("/api/analyze/blood-report", {
    method: "POST",
    token,
    body: {
      provider,
      profile,
      disease,
      labs
    }
  });
}

export async function saveReportRecord({ record, token }) {
  return request("/api/reports", {
    method: "POST",
    token,
    body: record
  });
}

export async function listReportHistory(token) {
  return request("/api/reports", { token });
}
